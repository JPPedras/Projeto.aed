#ifndef AnalysisHeader
#define AnalysisHeader

#include"files.h"

int check_a(pb *prob);  //problema A
int check_b(pb *prob);  //problema B
int check_c(pb *prob);  //problema C
void Tree_Tent(pb* prob,int n,int m,int *result);


#endif
